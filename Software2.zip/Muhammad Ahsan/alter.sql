ALTER TABLE address MODIFY COLUMN addressid INT auto_increment;
ALTER TABLE appointment MODIFY COLUMN appointmentid INT auto_increment;
ALTER TABLE city MODIFY COLUMN cityid INT auto_increment;
ALTER TABLE country MODIFY COLUMN countryid INT auto_increment;
ALTER TABLE customer MODIFY COLUMN customerid INT auto_increment;
ALTER TABLE reminder MODIFY COLUMN reminderid INT auto_increment;
ALTER TABLE user MODIFY COLUMN userid INT auto_increment;